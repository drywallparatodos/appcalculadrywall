class UserModel {
  final String id;
  final String email;
  final String name;
  final String companyName;
  final String address;
  final String phone;
  final String logoUrl;
  final String signatureUrl;
  final String defaultSlogan;
  final String hotmartStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.id,
    required this.email,
    required this.name,
    required this.companyName,
    required this.address,
    required this.phone,
    required this.logoUrl,
    this.signatureUrl = '',
    required this.defaultSlogan,
    required this.hotmartStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'email': email,
    'name': name,
    'companyName': companyName,
    'address': address,
    'phone': phone,
    'logoUrl': logoUrl,
    'signatureUrl': signatureUrl,
    'defaultSlogan': defaultSlogan,
    'hotmartStatus': hotmartStatus,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
  };

  factory UserModel.fromJson(String id, Map<String, dynamic> json) => UserModel(
    id: id,
    email: json['email'] ?? '',
    name: json['name'] ?? '',
    companyName: json['companyName'] ?? '',
    address: json['address'] ?? '',
    phone: json['phone'] ?? '',
    logoUrl: json['logoUrl'] ?? '',
    signatureUrl: json['signatureUrl'] ?? '',
    defaultSlogan: json['defaultSlogan'] ?? '',
    hotmartStatus: json['hotmartStatus'] ?? 'inactive',
    createdAt: json['createdAt']?.toDate() ?? DateTime.now(),
    updatedAt: json['updatedAt']?.toDate() ?? DateTime.now(),
  );
}

class QuoteModel {
  final String id;
  final String userId;
  final String customerName;
  final String customerAddress;
  final int validity;
  final String serviceType;
  final double area;
  final double footHeight;
  final String sheetType;
  final bool includeInsulation;
  final List<MaterialItem> materials;
  final List<ServiceItem> services;
  final List<ExtraCost> extraCosts;
  final double totalValue;
  final String customMessage;
  final DateTime createdAt;
  final DateTime updatedAt;

  QuoteModel({
    required this.id,
    required this.userId,
    required this.customerName,
    required this.customerAddress,
    required this.validity,
    required this.serviceType,
    required this.area,
    required this.footHeight,
    required this.sheetType,
    required this.includeInsulation,
    required this.materials,
    required this.services,
    required this.extraCosts,
    required this.totalValue,
    required this.customMessage,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'userId': userId,
    'customerName': customerName,
    'customerAddress': customerAddress,
    'validity': validity,
    'serviceType': serviceType,
    'area': area,
    'footHeight': footHeight,
    'sheetType': sheetType,
    'includeInsulation': includeInsulation,
    'materials': materials.map((m) => m.toJson()).toList(),
    'services': services.map((s) => s.toJson()).toList(),
    'extraCosts': extraCosts.map((e) => e.toJson()).toList(),
    'totalValue': totalValue,
    'customMessage': customMessage,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
  };

  factory QuoteModel.fromJson(String id, Map<String, dynamic> json) => QuoteModel(
    id: id,
    userId: json['userId'] ?? '',
    customerName: json['customerName'] ?? '',
    customerAddress: json['customerAddress'] ?? '',
    validity: json['validity'] ?? 30,
    serviceType: json['serviceType'] ?? '',
    area: (json['area'] ?? 0.0).toDouble(),
    footHeight: (json['footHeight'] ?? 0.0).toDouble(),
    sheetType: json['sheetType'] ?? '',
    includeInsulation: json['includeInsulation'] ?? false,
    materials: (json['materials'] as List<dynamic>?)
        ?.map((m) => MaterialItem.fromJson(m))
        .toList() ?? [],
    services: (json['services'] as List<dynamic>?)
        ?.map((s) => ServiceItem.fromJson(s))
        .toList() ?? [],
    extraCosts: (json['extraCosts'] as List<dynamic>?)
        ?.map((e) => ExtraCost.fromJson(e))
        .toList() ?? [],
    totalValue: (json['totalValue'] ?? 0.0).toDouble(),
    customMessage: json['customMessage'] ?? '',
    createdAt: json['createdAt']?.toDate() ?? DateTime.now(),
    updatedAt: json['updatedAt']?.toDate() ?? DateTime.now(),
  );
}

class MaterialItem {
  final String name;
  final String unit;
  final double quantity;
  final double factor;

  MaterialItem({
    required this.name,
    required this.unit,
    required this.quantity,
    required this.factor,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'unit': unit,
    'quantity': quantity,
    'factor': factor,
  };

  factory MaterialItem.fromJson(Map<String, dynamic> json) => MaterialItem(
    name: json['name'] ?? '',
    unit: json['unit'] ?? '',
    quantity: (json['quantity'] ?? 0.0).toDouble(),
    factor: (json['factor'] ?? 0.0).toDouble(),
  );
}

class ServiceItem {
  final String description;
  final double area;
  final double pricePerM2;
  final double total;

  ServiceItem({
    required this.description,
    required this.area,
    required this.pricePerM2,
    required this.total,
  });

  Map<String, dynamic> toJson() => {
    'description': description,
    'area': area,
    'pricePerM2': pricePerM2,
    'total': total,
  };

  factory ServiceItem.fromJson(Map<String, dynamic> json) => ServiceItem(
    description: json['description'] ?? '',
    area: (json['area'] ?? 0.0).toDouble(),
    pricePerM2: (json['pricePerM2'] ?? 0.0).toDouble(),
    total: (json['total'] ?? 0.0).toDouble(),
  );
}

class ExtraCost {
  final String description;
  final double amount;

  ExtraCost({
    required this.description,
    required this.amount,
  });

  Map<String, dynamic> toJson() => {
    'description': description,
    'amount': amount,
  };

  factory ExtraCost.fromJson(Map<String, dynamic> json) => ExtraCost(
    description: json['description'] ?? '',
    amount: (json['amount'] ?? 0.0).toDouble(),
  );
}