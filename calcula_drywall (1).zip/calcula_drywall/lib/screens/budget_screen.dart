import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../services/calculation_service.dart';
import '../services/pdf_service.dart';
import '../data_schema.dart';
import '../theme.dart';

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});

  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> with TickerProviderStateMixin {
  final _authService = AuthService();
  final _firestore = FirebaseFirestore.instance;
  final _formKey = GlobalKey<FormState>();
  
  // Form controllers
  final _customerNameController = TextEditingController();
  final _customerAddressController = TextEditingController();
  final _footHeightController = TextEditingController();
  final _pricePerM2Controller = TextEditingController();
  final _customMessageController = TextEditingController();
  
  // Form data
  int _validity = 30;
  String? _selectedServiceType;
  String _selectedSheetType = 'ST (Standard)';
  bool _includeInsulation = false;
  bool _includeMaterials = true;
  String _selectedLayout = 'Simples'; // Layout do orçamento
  
  // Calculated data
  List<MaterialItem> _materials = [];
  List<ServiceItem> _services = [];
  List<ExtraCost> _extraCosts = [];
  double _totalValue = 0.0;
  bool _canProceed = false; // Controla se o botão próximo pode ser habilitado
  
  // UI state
  bool _isLoading = false;
  int _currentStep = 0;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
    
    // Adiciona listeners para verificar se os campos estão preenchidos
    _customerNameController.addListener(_checkCanProceed);
    _customerAddressController.addListener(_checkCanProceed);
    
    // Inicializa com valores padrão para facilitar o teste
    _validity = 15; // Validade padrão de 15 dias
  }

  @override
  void dispose() {
    _animationController.dispose();
    _customerNameController.dispose();
    _customerAddressController.dispose();
    _footHeightController.dispose();
    _pricePerM2Controller.dispose();
    _customMessageController.dispose();
    super.dispose();
  }

  void _calculateMaterials() {
    if (_selectedServiceType != null) {
      // Use a default area or a fixed area since we're removing the area field
      const area = 10.0; // Default area of 10 square meters
      setState(() {
        _materials = CalculationService.calculateMaterials(
          serviceType: _selectedServiceType!,
          area: area,
          includeInsulation: _includeInsulation,
        );
      });
    }
  }

  void _calculateServices() {
    if (_selectedServiceType != null) {
      // Use a default area since we're removing the area field
      const area = 10.0; // Default area of 10 square meters
      final pricePerM2 = 80.0; // Default price per m² that can be edited later
      
      // Verifica se já existe um serviço com descrição semelhante ao tipo selecionado
      bool hasMainService = false;
      for (var service in _services) {
        // Verifica se a descrição do serviço contém o tipo de serviço selecionado
        if (service.description.contains(_selectedServiceType!)) {
          hasMainService = true;
          break;
        }
      }
      
      setState(() {
        // Adiciona o serviço principal apenas se ainda não existir
        if (!hasMainService) {
          final newServices = CalculationService.calculateServices(
            serviceType: _selectedServiceType!,
            area: area,
            pricePerM2: pricePerM2,
          );
          
          _services.addAll(newServices);
        }
        
        _calculateTotal();
        _checkCanProceed(); // Verifica se pode avançar
      });
    }
  }

  void _calculateTotal() {
    double total = 0.0;
    for (final service in _services) {
      total += service.total;
    }
    for (final extraCost in _extraCosts) {
      total += extraCost.amount;
    }
    setState(() {
      _totalValue = total;
      _checkCanProceed();
    });
  }
  
  void _checkCanProceed() {
    // Verifica se todas as informações necessárias foram preenchidas para cada etapa
    bool canProceed = false;
    
    switch (_currentStep) {
      case 0: // Dados do cliente
        canProceed = _customerNameController.text.isNotEmpty && 
                      _customerAddressController.text.isNotEmpty;
        break;
      case 1: // Projeto
        canProceed = _selectedServiceType != null;
        if (canProceed && _materials.isEmpty) {
          // Calculate materials if they haven't been calculated yet
          _calculateMaterials();
        }
        break;
      case 2: // Serviços
        canProceed = true; // Sempre pode prosseguir da etapa de serviços
        // Verificamos se existe pelo menos um serviço para continuar
        if (_services.isEmpty && _selectedServiceType != null) {
          _calculateServices();
        }
        break;
      case 3: // Resumo
        canProceed = true;
        break;
    }
    
    // Atualiza o estado para habilitar o botão "próximo"
    setState(() {
      _canProceed = canProceed;
    });
  }

  void _addExtraCost(String description, double amount) {
    setState(() {
      _extraCosts.add(ExtraCost(description: description, amount: amount));
      _calculateTotal();
    });
  }

  void _removeExtraCost(int index) {
    setState(() {
      _extraCosts.removeAt(index);
      _calculateTotal();
    });
  }

  Future<void> _saveQuote() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() => _isLoading = true);
    
    try {
      final user = _authService.currentUser;
      if (user == null) throw Exception('Usuário não logado');

      final quote = QuoteModel(
        id: '',
        userId: user.uid,
        customerName: _customerNameController.text.trim(),
        customerAddress: _customerAddressController.text.trim(),
        validity: _validity,
        serviceType: _selectedServiceType!,
        area: 10.0, // Default fixed area since we removed the area field
        footHeight: _footHeightController.text.isNotEmpty 
            ? double.parse(_footHeightController.text) 
            : 0.0,
        sheetType: _selectedSheetType,
        includeInsulation: _includeInsulation,
        materials: _includeMaterials ? _materials : [],
        services: _services,
        extraCosts: _extraCosts,
        totalValue: _totalValue,
        customMessage: _customMessageController.text.trim(),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _firestore.collection('quotes').add(quote.toJson());
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Orçamento salvo com sucesso!'),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
        );
        _generatePdf(quote);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao salvar: ${e.toString()}'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _generatePdf(QuoteModel quote) async {
    try {
      final userData = await _authService.getCurrentUserData();
      if (userData == null) throw Exception('Dados do usuário não encontrados');

      final pdfBytes = await PdfService.generateQuotePdf(
        quote: quote,
        user: userData,
        layout: _selectedLayout,
      );

      final fileName = 'Orcamento_${quote.customerName.replaceAll(' ', '_')}_${DateTime.now().millisecondsSinceEpoch}';
      
      // Mostra opções de ação para o PDF
      if (mounted) {
        _showPdfOptionsDialog(pdfBytes, fileName);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao gerar PDF: ${e.toString()}'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }
  
  void _showPdfOptionsDialog(Uint8List pdfBytes, String fileName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Orçamento Gerado'),
        content: const Text('Escolha o que deseja fazer com o orçamento:'),
        actions: [
          IconButton(
            icon: Icon(
              Icons.file_download,
              color: Theme.of(context).colorScheme.primary,
              size: 28,
            ),
            onPressed: () async {
              Navigator.pop(context);
              await PdfService.savePdf(
                pdfBytes: pdfBytes, 
                fileName: fileName,
              );
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('PDF salvo com sucesso!')),
                );
              }
            },
            tooltip: 'Baixar Orçamento',
          ),
          IconButton(
            icon: Icon(
              Icons.print,
              color: Theme.of(context).colorScheme.primary,
              size: 28,
            ),
            onPressed: () async {
              Navigator.pop(context);
              await PdfService.printPdf(pdfBytes);
            },
            tooltip: 'Imprimir',
          ),
          IconButton(
            icon: Icon(
              Icons.chat,
              color: Color(0xFF25D366), // WhatsApp green color
              size: 28,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                await PdfService.shareToWhatsApp(
                  pdfBytes: pdfBytes,
                  fileName: fileName,
                  message: 'Segue o orçamento solicitado!',
                );
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Erro ao compartilhar: ${e.toString()}')),
                  );
                }
              }
            },
            tooltip: 'Compartilhar via WhatsApp',
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Gerador de Orçamentos',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        elevation: 0,
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: Theme.of(context).colorScheme.primary,
            ),
          ),
          child: Stepper(
            currentStep: _currentStep,
            onStepContinue: () {
              if (_currentStep < 3) {
                // Se estiver na etapa 1 (Projeto) e indo para a etapa 2 (Serviços),
                // calcula os serviços automaticamente
                if (_currentStep == 1) {
                  _calculateServices();
                }
                
                setState(() {
                  _currentStep += 1;
                  _checkCanProceed(); // Verifica novamente após mudar de etapa
                });
              }
            },
            onStepCancel: () {
              if (_currentStep > 0) {
                setState(() {
                  _currentStep -= 1;
                  _checkCanProceed(); // Verifica novamente após mudar de etapa
                });
              }
            },
            onStepTapped: (step) {
              // Verifica se pode avançar para a etapa selecionada
              if (step > _currentStep) {
                // Só permite avançar se os dados da etapa atual estão preenchidos
                _checkCanProceed();
                if (!_canProceed) return;
                
                // Se estiver na etapa 1 (Projeto) e indo para a etapa 2 (Serviços),
                // calcula os serviços automaticamente
                if (_currentStep == 1 && step == 2) {
                  _calculateServices();
                }
              }
              
              setState(() {
                _currentStep = step;
                _checkCanProceed(); // Verifica novamente após mudar de etapa
              });
            },
            controlsBuilder: (context, details) {
              return Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Row(
                  children: [
                    if (details.stepIndex < 3)
                      ElevatedButton(
                        onPressed: _canProceed ? () {
                          // Se estiver na etapa 1 (Projeto) e indo para a etapa 2 (Serviços),
                          // calcula os serviços automaticamente
                          if (details.stepIndex == 1) {
                            _calculateServices();
                          }
                          details.onStepContinue?.call();
                          
                          // Atualiza o estado após mudar de etapa
                          Future.microtask(() {
                            if (mounted) {
                              setState(() {
                                _checkCanProceed();
                              });
                            }
                          });
                        } : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Theme.of(context).colorScheme.onPrimary,
                          disabledBackgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                          disabledForegroundColor: Theme.of(context).colorScheme.onPrimary.withOpacity(0.5),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text(
                          'Próximo',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onPrimary,
                          ),
                        ),
                      ),
                    if (details.stepIndex == 3)
                      ElevatedButton(
                        onPressed: _isLoading ? null : _saveQuote,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.tertiary,
                          foregroundColor: Theme.of(context).colorScheme.onTertiary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: _isLoading
                            ? SizedBox(
                                height: 16,
                                width: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Theme.of(context).colorScheme.onTertiary,
                                  ),
                                ),
                              )
                            : Text(
                                'Gerar Orçamento',
                                style: TextStyle(
                                  color: Theme.of(context).colorScheme.onTertiary,
                                ),
                              ),
                      ),
                    const SizedBox(width: 8),
                    if (details.stepIndex > 0)
                      TextButton(
                        onPressed: details.onStepCancel,
                        child: Text(
                          'Anterior',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
            steps: [
              Step(
                title: Text('Dados do Cliente'),
                content: _buildCustomerDataStep(),
                isActive: _currentStep >= 0,
                state: _currentStep > 0 ? StepState.complete : StepState.indexed,
              ),
              Step(
                title: Text('Projeto'),
                content: _buildProjectDataStep(),
                isActive: _currentStep >= 1,
                state: _currentStep > 1 ? StepState.complete : StepState.indexed,
              ),
              Step(
                title: Text('Serviços'),
                content: _buildServicesStep(),
                isActive: _currentStep >= 2,
                state: _currentStep > 2 ? StepState.complete : StepState.indexed,
              ),
              Step(
                title: Text('Resumo'),
                content: _buildSummaryStep(),
                isActive: _currentStep >= 3,
                state: _currentStep == 3 ? StepState.indexed : StepState.disabled,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomerDataStep() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          _buildTextField(
            controller: _customerNameController,
            label: 'Nome do Cliente',
            icon: Icons.person,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, insira o nome do cliente';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          _buildTextField(
            controller: _customerAddressController,
            label: 'Endereço do Cliente (Rua, número e complemento)',
            icon: Icons.home,
            maxLines: 2,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, insira o endereço do cliente';
              }
              return null;
            },
            hintText: 'Ex: Rua Exemplo, 123 - Apto 101',
          ),
          const SizedBox(height: 16),
          _buildValidityDropdown(),
        ],
      ),
    );
  }

  Widget _buildProjectDataStep() {
    return Column(
      children: [
        _buildServiceTypeDropdown(),
        const SizedBox(height: 16),
        if (_selectedServiceType?.contains('Forro') == true)
          Row(
            children: [
              Expanded(
                child: _buildTextField(
                  controller: _footHeightController,
                  label: 'Pé-direito (m)',
                  icon: Icons.height,
                  keyboardType: TextInputType.number,
                ),
              ),
            ],
          ),
        const SizedBox(height: 16),
        _buildSheetTypeDropdown(),
        const SizedBox(height: 16),
        _buildInsulationCheckbox(),
        const SizedBox(height: 16),
        _buildMaterialsCheckbox(),
      ],
    );
  }

  Widget _buildServicesStep() {
    return Column(
      children: [
        _buildServicesList(),
        const SizedBox(height: 16),
        _buildExtraCostsSection(),
        const SizedBox(height: 16),
        _buildLayoutSelection(),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _customMessageController,
          label: 'Mensagem Personalizada (Opcional)',
          icon: Icons.message,
          maxLines: 3,
        ),
      ],
    );
  }
  
  Widget _buildServicesList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Serviços',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            IconButton(
              icon: Icon(
                Icons.add_circle,
                color: Theme.of(context).colorScheme.primary,
              ),
              onPressed: _showAddServiceDialog,
            ),
          ],
        ),
        ..._services.asMap().entries.map((entry) {
          final index = entry.key;
          final service = entry.value;
          return Card(
            child: ListTile(
              title: Text(service.description),
              subtitle: Text('Área: ${service.area.toStringAsFixed(2)} m² - Valor: R\$ ${service.pricePerM2.toStringAsFixed(2)}/m²'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'R\$ ${service.total.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.delete,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    onPressed: () => _removeService(index),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
  
  void _showAddServiceDialog() {
    final descriptionController = TextEditingController();
    final areaController = TextEditingController();
    final priceController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Adicionar Serviço'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Descrição',
                hintText: 'Ex: Instalação de forro',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: areaController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
              ],
              decoration: const InputDecoration(
                labelText: 'Área (m²)',
                hintText: 'Ex: 25.5',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: priceController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
              ],
              decoration: const InputDecoration(
                labelText: 'Valor por m² (R\$)',
                hintText: 'Ex: 65.00',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancelar',
              style: TextStyle(
                color: Theme.of(context).colorScheme.outline,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (descriptionController.text.isNotEmpty &&
                  areaController.text.isNotEmpty &&
                  priceController.text.isNotEmpty) {
                final area = double.parse(areaController.text);
                final price = double.parse(priceController.text);
                _addService(
                  descriptionController.text,
                  area,
                  price,
                );
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
            ),
            child: Text(
              'Adicionar',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _addService(String description, double area, double pricePerM2) {
    final total = area * pricePerM2;
    setState(() {
      _services.add(ServiceItem(
        description: description,
        area: area,
        pricePerM2: pricePerM2,
        total: total,
      ));
      _calculateTotal();
    });
  }

  void _removeService(int index) {
    setState(() {
      _services.removeAt(index);
      _calculateTotal();
    });
  }
  
  Widget _buildLayoutSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Layout do Orçamento',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Column(
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildLayoutOption('Simples', 'Layout básico com informações essenciais'),
                      _buildLayoutOption('Padrão', 'Layout com informações detalhadas'),
                      _buildLayoutOption('Detalhado', 'Layout completo com todos os detalhes'),
                      _buildLayoutOption('Profissional', 'Layout elegante com logo e assinatura'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  // These methods have been removed as they're no longer needed
  
  Widget _buildLayoutOption(String title, String description) {
    final isSelected = _selectedLayout == title;
    
    return InkWell(
      onTap: () {
        setState(() {
          _selectedLayout = title;
        });
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: MediaQuery.of(context).size.width / 2 - 24,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.1)
              : Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.outline.withOpacity(0.5),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  isSelected ? Icons.check_circle : Icons.circle_outlined,
                  color: isSelected
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outline,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isSelected
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              description,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSummaryCard(),
        if (_includeMaterials && _materials.isNotEmpty) ...[
          const SizedBox(height: 16),
          _buildMaterialsSummary(),
        ],
        if (_services.isNotEmpty) ...[
          const SizedBox(height: 16),
          _buildServicesSummary(),
        ],
        if (_extraCosts.isNotEmpty) ...[
          const SizedBox(height: 16),
          _buildExtraCostsSummary(),
        ],
        const SizedBox(height: 16),
        _buildTotalCard(),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    String? Function(String?)? validator,
    void Function(String)? onChanged,
    String? hintText,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      validator: validator,
      onChanged: onChanged,
      inputFormatters: keyboardType == TextInputType.number
          ? [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))]
          : null,
      decoration: InputDecoration(
        labelText: label,
        hintText: hintText,
        prefixIcon: Icon(
          icon,
          color: Theme.of(context).colorScheme.primary,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Theme.of(context).colorScheme.primary,
            width: 2,
          ),
        ),
      ),
    );
  }

  Widget _buildValidityDropdown() {
    return DropdownButtonFormField<int>(
      value: _validity,
      decoration: InputDecoration(
        labelText: 'Validade do Orçamento',
        prefixIcon: Icon(
          Icons.calendar_today,
          color: Theme.of(context).colorScheme.primary,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      items: [7, 15, 30, 45, 60]
          .map((days) => DropdownMenuItem(
                value: days,
                child: Text('$days dias'),
              ))
          .toList(),
      onChanged: (value) {
        setState(() {
          _validity = value!;
        });
      },
    );
  }

  Widget _buildServiceTypeDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedServiceType,
      decoration: InputDecoration(
        labelText: 'Tipo de Serviço',
        prefixIcon: Icon(
          Icons.construction,
          color: Theme.of(context).colorScheme.primary,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      items: CalculationService.getAvailableServiceTypes()
          .map((type) => DropdownMenuItem(
                value: type,
                child: Text(type),
              ))
          .toList(),
      onChanged: (value) {
        setState(() {
          _selectedServiceType = value;
          _calculateMaterials();
          _checkCanProceed(); // Check if we can proceed after selecting a service type
        });
      },
      validator: (value) {
        if (value == null) {
          return 'Selecione o tipo de serviço';
        }
        return null;
      },
    );
  }

  Widget _buildSheetTypeDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedSheetType,
      decoration: InputDecoration(
        labelText: 'Tipo de Chapa',
        prefixIcon: Icon(
          Icons.crop_square,
          color: Theme.of(context).colorScheme.primary,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      items: CalculationService.getAvailableSheetTypes()
          .map((type) => DropdownMenuItem(
                value: type,
                child: Text(type),
              ))
          .toList(),
      onChanged: (value) {
        setState(() {
          _selectedSheetType = value!;
        });
      },
    );
  }

  Widget _buildInsulationCheckbox() {
    return CheckboxListTile(
      title: const Text('Incluir isolamento térmico/acústico'),
      subtitle: const Text('Lã de vidro ou lã de rocha'),
      value: _includeInsulation,
      onChanged: (value) {
        setState(() {
          _includeInsulation = value ?? false;
          _calculateMaterials();
        });
      },
      activeColor: Theme.of(context).colorScheme.primary,
    );
  }

  Widget _buildMaterialsCheckbox() {
    return CheckboxListTile(
      title: const Text('Incluir lista de materiais no orçamento'),
      value: _includeMaterials,
      onChanged: (value) {
        setState(() {
          _includeMaterials = value ?? false;
        });
      },
      activeColor: Theme.of(context).colorScheme.primary,
    );
  }

  Widget _buildExtraCostsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Custos Extras',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            IconButton(
              icon: Icon(
                Icons.add_circle,
                color: Theme.of(context).colorScheme.primary,
              ),
              onPressed: _showAddExtraCostDialog,
            ),
          ],
        ),
        ..._extraCosts.asMap().entries.map((entry) {
          final index = entry.key;
          final extraCost = entry.value;
          return Card(
            child: ListTile(
              title: Text(extraCost.description),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'R\$ ${extraCost.amount.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.delete,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    onPressed: () => _removeExtraCost(index),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }

  void _showAddExtraCostDialog() {
    final descriptionController = TextEditingController();
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Adicionar Custo Extra'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Descrição',
                hintText: 'Ex: Transporte, alimentação',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
              ],
              decoration: const InputDecoration(
                labelText: 'Valor (R\$)',
                hintText: 'Ex: 150.00',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancelar',
              style: TextStyle(
                color: Theme.of(context).colorScheme.outline,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (descriptionController.text.isNotEmpty &&
                  amountController.text.isNotEmpty) {
                _addExtraCost(
                  descriptionController.text,
                  double.parse(amountController.text),
                );
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
            ),
            child: Text(
              'Adicionar',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Resumo do Orçamento',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildSummaryRow('Cliente:', _customerNameController.text),
            _buildSummaryRow('Endereço:', _customerAddressController.text),
            _buildSummaryRow('Serviço:', _selectedServiceType ?? ''),
            _buildSummaryRow('Validade:', '$_validity dias'),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMaterialsSummary() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Materiais',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            ..._materials.map((material) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    '• ${material.name}: ${CalculationService.formatQuantity(material.quantity, material.unit)}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildServicesSummary() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Serviços',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            ..._services.map((service) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    '• ${service.description}: R\$ ${service.total.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildExtraCostsSummary() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Custos Extras',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            ..._extraCosts.map((cost) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    '• ${cost.description}: R\$ ${cost.amount.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalCard() {
    return Card(
      color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'VALOR TOTAL',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            Text(
              'R\$ ${_totalValue.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}