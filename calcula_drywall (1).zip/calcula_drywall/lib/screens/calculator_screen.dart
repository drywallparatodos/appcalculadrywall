import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:typed_data';
import '../services/calculation_service.dart';
import '../services/auth_service.dart';
import '../services/pdf_service.dart';
import '../data_schema.dart';
import '../theme.dart';

class CalculatorScreen extends StatefulWidget {
  final String? initialServiceType;
  
  const CalculatorScreen({super.key, this.initialServiceType});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _areaController = TextEditingController();
  final _footHeightController = TextEditingController();
  
  String? _selectedMainType;
  String? _selectedSubType;
  String _selectedSheetType = 'ST (Standard)';
  bool _includeInsulation = false;
  List<MaterialItem> _calculatedMaterials = [];
  bool _hasCalculated = false;
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    if (widget.initialServiceType != null) {
      // Set initial service type if provided
      for (final mainType in CalculationService.getMainServiceTypes()) {
        final subtypes = CalculationService.getServiceSubtypes(mainType);
        if (subtypes.contains(widget.initialServiceType)) {
          _selectedMainType = mainType;
          _selectedSubType = widget.initialServiceType;
          break;
        }
      }
    }
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController, 
      curve: Curves.easeOutBack,
    ));
    
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _areaController.dispose();
    _footHeightController.dispose();
    super.dispose();
  }

  void _calculate() {
    if (!_formKey.currentState!.validate() || _selectedSubType == null) {
      return;
    }

    final area = double.parse(_areaController.text);
    
    setState(() {
      _calculatedMaterials = CalculationService.calculateMaterials(
        serviceType: _selectedSubType!,
        area: area,
        includeInsulation: _includeInsulation,
      );
      _hasCalculated = true;
    });

    // Scroll to results
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        Scrollable.ensureVisible(
          context,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  void _reset() {
    setState(() {
      _areaController.clear();
      _footHeightController.clear();
      _selectedMainType = null;
      _selectedSubType = null;
      _selectedSheetType = 'ST (Standard)';
      _includeInsulation = false;
      _calculatedMaterials = [];
      _hasCalculated = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Calculadora de Materiais',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        elevation: 0,
        actions: [
          if (_hasCalculated)
            IconButton(
              icon: Icon(
                Icons.refresh,
                color: Theme.of(context).colorScheme.onPrimary,
              ),
              onPressed: _reset,
              tooltip: 'Novo Cálculo',
            ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: SlideTransition(
            position: _slideAnimation,
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildServiceTypeSection(),
                  const SizedBox(height: 24),
                  _buildInputSection(),
                  const SizedBox(height: 24),
                  _buildCalculateButton(),
                  if (_hasCalculated) ...[
                    const SizedBox(height: 32),
                    _buildResultsSection(),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildServiceTypeSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.construction,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Text(
                  'Tipo de Serviço',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Main service type (Parede or Teto)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedMainType,
                  hint: Text(
                    'Selecione o tipo de serviço',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                  isExpanded: true,
                  icon: Icon(
                    Icons.arrow_drop_down,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  items: CalculationService.getMainServiceTypes()
                      .map((type) => DropdownMenuItem(
                            value: type,
                            child: Text(type),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedMainType = value;
                      _selectedSubType = null;
                      _hasCalculated = false;
                    });
                  },
                ),
              ),
            ),
            if (_selectedMainType != null) ...[               
              const SizedBox(height: 16),
              // Subtype based on main type
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedSubType,
                    hint: Text(
                      'Selecione o subtipo',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                    isExpanded: true,
                    icon: Icon(
                      Icons.arrow_drop_down,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    items: CalculationService.getServiceSubtypes(_selectedMainType!)
                        .map((type) => DropdownMenuItem(
                              value: type,
                              child: Text(type),
                            ))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedSubType = value;
                        _hasCalculated = false;
                      });
                    },
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInputSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.straighten,
                  color: Theme.of(context).colorScheme.secondary,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Text(
                  'Dados de Entrada',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: _areaController,
              label: 'Área (m²)',
              hint: 'Ex: 25.5',
              icon: Icons.square_foot,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, insira a área';
                }
                final area = double.tryParse(value);
                if (area == null || area <= 0) {
                  return 'Insira um valor válido maior que zero';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            if (_selectedMainType == 'Parede') ...[
              _buildTextField(
                controller: _footHeightController,
                label: 'Pé-direito (m)',
                hint: 'Ex: 2.8',
                icon: Icons.height,
                validator: (value) {
                  if (value != null && value.isNotEmpty) {
                    final height = double.tryParse(value);
                    if (height == null || height <= 0) {
                      return 'Insira um valor válido maior que zero';
                    }
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
            ],
            _buildSheetTypeDropdown(),
            const SizedBox(height: 16),
            _buildInsulationCheckbox(),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
      ],
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(
          icon,
          color: Theme.of(context).colorScheme.primary,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Theme.of(context).colorScheme.primary,
            width: 2,
          ),
        ),
        filled: true,
        fillColor: Theme.of(context).colorScheme.surface,
      ),
    );
  }

  Widget _buildSheetTypeDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tipo de Chapa',
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            border: Border.all(
              color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedSheetType,
              isExpanded: true,
              icon: Icon(
                Icons.arrow_drop_down,
                color: Theme.of(context).colorScheme.primary,
              ),
              items: CalculationService.getAvailableSheetTypes()
                  .map((type) => DropdownMenuItem(
                        value: type,
                        child: Text(type),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedSheetType = value!;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInsulationCheckbox() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.tertiary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.tertiary.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Checkbox(
            value: _includeInsulation,
            onChanged: (value) {
              setState(() {
                _includeInsulation = value ?? false;
              });
            },
            activeColor: Theme.of(context).colorScheme.tertiary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Incluir isolamento térmico/acústico',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Lã de vidro ou lã de rocha',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalculateButton() {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _selectedSubType != null ? _calculate : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Theme.of(context).colorScheme.onPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 4,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.calculate,
              color: Theme.of(context).colorScheme.onPrimary,
            ),
            const SizedBox(width: 12),
            Text(
              'Calcular Materiais',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Theme.of(context).colorScheme.onPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultsSection() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.inventory_2,
                      color: Theme.of(context).colorScheme.tertiary,
                      size: 24,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Lista de Materiais',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).colorScheme.tertiary,
                      ),
                    ),
                  ],
                ),
                // Botões de ações para o cálculo
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.file_download,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      onPressed: () => _generateAndDownloadPdf(),
                      tooltip: 'Baixar',
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.print,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      onPressed: () => _generateAndPrintPdf(),
                      tooltip: 'Imprimir',
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.share,
                        color: Color(0xFF25D366), // WhatsApp green color
                      ),
                      onPressed: () => _shareCalculationViaWhatsApp(),
                      tooltip: 'Compartilhar via WhatsApp',
                    ),
                  ],
                ),
                
              ],
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: Theme.of(context).colorScheme.primary,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Para ${_areaController.text} m² de ${_selectedSubType}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ..._calculatedMaterials.map((material) => _buildMaterialItem(material)).toList(),
          ],
        ),
      ),
    );
  }
  
  Future<void> _generateAndDownloadPdf() async {
    try {
      final userData = await AuthService().getCurrentUserData();
      if (userData == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Dados do usuário não encontrados. Faça login para continuar.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }
      
      final area = double.parse(_areaController.text);
      final calculatedMaterials = _calculatedMaterials;
      
      final pdfBytes = await _generateCalculatorPdf(userData, area, calculatedMaterials);
      final fileName = 'Calculadora_${_selectedSubType?.replaceAll(' ', '_') ?? 'Materiais'}_${DateTime.now().millisecondsSinceEpoch}';
      
      await PdfService.savePdf(pdfBytes: pdfBytes, fileName: fileName);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PDF salvo com sucesso!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao gerar PDF: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  Future<void> _shareCalculationViaWhatsApp() async {
    try {
      final userData = await AuthService().getCurrentUserData();
      if (userData == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Dados do usuário não encontrados. Faça login para continuar.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }
      
      final area = double.parse(_areaController.text);
      final calculatedMaterials = _calculatedMaterials;
      
      final pdfBytes = await _generateCalculatorPdf(userData, area, calculatedMaterials);
      final fileName = 'Calculadora_${_selectedSubType?.replaceAll(' ', '_') ?? 'Materiais'}_${DateTime.now().millisecondsSinceEpoch}';
      
      await PdfService.shareToWhatsApp(
        pdfBytes: pdfBytes, 
        fileName: fileName,
        message: 'Segue o cálculo de materiais para ${_areaController.text} m² de ${_selectedSubType}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao compartilhar: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _generateAndPrintPdf() async {
    try {
      final userData = await AuthService().getCurrentUserData();
      if (userData == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Dados do usuário não encontrados. Faça login para continuar.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }
      
      final area = double.parse(_areaController.text);
      final calculatedMaterials = _calculatedMaterials;
      
      final pdfBytes = await _generateCalculatorPdf(userData, area, calculatedMaterials);
      await PdfService.printPdf(pdfBytes);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao imprimir: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  Future<Uint8List> _generateCalculatorPdf(UserModel user, double area, List<MaterialItem> materials) async {
    return await PdfService.generateCalculatorPdf(
      user: user,
      serviceType: _selectedSubType ?? 'Materiais',
      area: area,
      sheetType: _selectedSheetType,
      includeInsulation: _includeInsulation,
      materials: materials,
    );
  }



  Widget _buildMaterialItem(MaterialItem material) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              _getMaterialIcon(material.name),
              color: Theme.of(context).colorScheme.secondary,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  material.name,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Fator: ${material.factor} ${material.unit}/m²',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.tertiary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              CalculationService.formatQuantity(material.quantity, material.unit),
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Theme.of(context).colorScheme.tertiary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getMaterialIcon(String materialName) {
    if (materialName.toLowerCase().contains('chapa')) {
      return Icons.crop_square;
    } else if (materialName.toLowerCase().contains('montante') || 
               materialName.toLowerCase().contains('perfil')) {
      return Icons.view_column;
    } else if (materialName.toLowerCase().contains('guia')) {
      return Icons.horizontal_rule;
    } else if (materialName.toLowerCase().contains('parafuso')) {
      return Icons.construction;
    } else if (materialName.toLowerCase().contains('fita')) {
      return Icons.straighten;
    } else if (materialName.toLowerCase().contains('massa')) {
      return Icons.format_paint;
    } else if (materialName.toLowerCase().contains('cola')) {
      return Icons.format_color_fill;
    } else if (materialName.toLowerCase().contains('lã')) {
      return Icons.waves;
    } else if (materialName.toLowerCase().contains('arame')) {
      return Icons.cable;
    } else if (materialName.toLowerCase().contains('pendural')) {
      return Icons.vertical_align_center;
    } else if (materialName.toLowerCase().contains('conector')) {
      return Icons.link;
    }
    return Icons.inventory_2;
  }
}