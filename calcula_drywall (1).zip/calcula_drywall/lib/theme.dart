import 'package:flutter/material.dart';
import 'dart:ui';

// Extension to add drop shadow to Image widgets
extension ImageEffects on Image {
  Widget addDropShadow({
    double blurRadius = 5.0,
    Offset offset = const Offset(0, 3),
    double opacity = 0.5,
  }) {
    return Container(
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(opacity),
            blurRadius: blurRadius,
            offset: offset,
          ),
        ],
      ),
      child: this,
    );
  }
}

// App constants
const String appName = 'Calculadora Drywall Pro';
const String appLogo = 'assets/logo.png'; // Logo path

// Light theme colors
final ColorScheme lightColorScheme = ColorScheme.light(
  primary: const Color(0xFF0D47A1),     // Deep blue
  onPrimary: Colors.white,
  primaryContainer: const Color(0xFFE3F2FD),
  secondary: const Color(0xFF00796B),   // Teal
  onSecondary: Colors.white,
  secondaryContainer: const Color(0xFFB2DFDB),
  tertiary: const Color(0xFFC2185B),    // Pink
  onTertiary: Colors.white,
  tertiaryContainer: const Color(0xFFFCE4EC),
  error: const Color(0xFFB00020),
  surface: Colors.white,
  background: const Color(0xFFF5F5F5),
);

// Dark theme colors
final ColorScheme darkColorScheme = ColorScheme.dark(
  primary: const Color(0xFF64B5F6),     // Light blue
  onPrimary: Colors.black,
  primaryContainer: const Color(0xFF1565C0),
  secondary: const Color(0xFF4DB6AC),   // Light teal
  onSecondary: Colors.black,
  secondaryContainer: const Color(0xFF00695C),
  tertiary: const Color(0xFFF48FB1),    // Light pink
  onTertiary: Colors.black,
  tertiaryContainer: const Color(0xFF880E4F),
  error: const Color(0xFFCF6679),
  surface: const Color(0xFF121212),
  background: const Color(0xFF1E1E1E),
);

// Typography
TextTheme _buildTextTheme(TextTheme base) {
  return base.copyWith(
    displayLarge: base.displayLarge!.copyWith(fontWeight: FontWeight.w700),
    displayMedium: base.displayMedium!.copyWith(fontWeight: FontWeight.w700),
    displaySmall: base.displaySmall!.copyWith(fontWeight: FontWeight.w700),
    headlineLarge: base.headlineLarge!.copyWith(fontWeight: FontWeight.w700),
    headlineMedium: base.headlineMedium!.copyWith(fontWeight: FontWeight.w600),
    titleLarge: base.titleLarge!.copyWith(fontWeight: FontWeight.w600),
    bodyLarge: base.bodyLarge,
    bodyMedium: base.bodyMedium,
  );
}

// Light theme
final ThemeData lightTheme = ThemeData(
  useMaterial3: true,
  colorScheme: lightColorScheme,
  scaffoldBackgroundColor: lightColorScheme.background,
  textTheme: _buildTextTheme(ThemeData.light().textTheme),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      foregroundColor: lightColorScheme.onPrimary,
      backgroundColor: lightColorScheme.primary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  ),
  cardTheme: CardTheme(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    elevation: 2,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: lightColorScheme.primary,
    foregroundColor: lightColorScheme.onPrimary,
    centerTitle: true,
    elevation: 2,
  ),
);

// Dark theme
final ThemeData darkTheme = ThemeData(
  useMaterial3: true,
  colorScheme: darkColorScheme,
  scaffoldBackgroundColor: darkColorScheme.background,
  textTheme: _buildTextTheme(ThemeData.dark().textTheme),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      foregroundColor: darkColorScheme.onPrimary,
      backgroundColor: darkColorScheme.primary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    filled: true,
    fillColor: darkColorScheme.surface,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  ),
  cardTheme: CardTheme(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    elevation: 2,
    color: darkColorScheme.surface,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: darkColorScheme.primary,
    foregroundColor: darkColorScheme.onPrimary,
    centerTitle: true,
    elevation: 2,
  ),
);