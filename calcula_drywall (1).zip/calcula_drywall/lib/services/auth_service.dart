import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../data_schema.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserModel?> getCurrentUserData() async {
    final user = currentUser;
    if (user == null) return null;
    
    final doc = await _firestore.collection('users').doc(user.uid).get();
    if (!doc.exists) return null;
    
    return UserModel.fromJson(doc.id, doc.data()!);
  }

  Future<UserCredential?> signInWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.signInWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      throw Exception('Erro ao fazer login: ${e.toString()}');
    }
  }

  Future<UserCredential?> createUserWithEmailAndPassword(String email, String password, String name, String companyName) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      
      if (credential.user != null) {
        await _createUserDocument(credential.user!, name, companyName);
      }
      
      return credential;
    } catch (e) {
      throw Exception('Erro ao criar conta: ${e.toString()}');
    }
  }

  Future<void> _createUserDocument(User user, String name, String companyName) async {
    final userData = UserModel(
      id: user.uid,
      email: user.email ?? '',
      name: name,
      companyName: companyName,
      address: '',
      phone: '',
      logoUrl: '',
      defaultSlogan: 'Qualidade e confiança em cada projeto',
      hotmartStatus: 'active', // For MVP, all users are active
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await _firestore.collection('users').doc(user.uid).set(userData.toJson());
  }

  Future<void> updateUserProfile(UserModel userModel) async {
    final user = currentUser;
    if (user == null) throw Exception('Usuário não logado');

    await _firestore.collection('users').doc(user.uid).update({
      'name': userModel.name,
      'companyName': userModel.companyName,
      'address': userModel.address,
      'phone': userModel.phone,
      'defaultSlogan': userModel.defaultSlogan,
      'updatedAt': DateTime.now(),
    });
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  bool isUserActive(UserModel? userModel) {
    return userModel?.hotmartStatus == 'active';
  }
}