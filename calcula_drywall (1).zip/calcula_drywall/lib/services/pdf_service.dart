import 'dart:io';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../data_schema.dart';

class PdfService {
  static Future<Uint8List> generateQuotePdf({
    required QuoteModel quote,
    required UserModel user,
    String layout = 'Padrão',
  }) async {
    final pdf = pw.Document();
    
    // Carrega a assinatura do usuário se disponível
    pw.Widget? signatureWidget;
    if (user.signatureUrl.isNotEmpty) {
      try {
        final signatureBytes = await getImageFromUrl(user.signatureUrl);
        if (signatureBytes != null) {
          final signatureImage = pw.MemoryImage(signatureBytes);
          signatureWidget = pw.Container(
            height: 60,
            width: 120,
            decoration: pw.BoxDecoration(
              image: pw.DecorationImage(
                image: signatureImage,
                fit: pw.BoxFit.contain,
              ),
            ),
          );
        }
      } catch (e) {
        print('Erro ao carregar assinatura: $e');
      }
    }
    
    // Primeiro construa o header antes de adicionar a página
    final headerWidget = await _buildHeader(user);

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (pw.Context context) {
          final widgets = <pw.Widget>[
            headerWidget,
            pw.SizedBox(height: 20),
            _buildCustomerInfo(quote),
            pw.SizedBox(height: 20),
            _buildProjectDetails(quote),
            pw.SizedBox(height: 20),
          ];
          
          // Adiciona materiais dependendo do layout
          if (layout == 'Detalhado' || layout == 'Profissional' || quote.materials.isNotEmpty) {
            widgets.add(_buildMaterialsList(quote.materials));
            widgets.add(pw.SizedBox(height: 20));
          }
          
          // Adiciona serviços
          if (quote.services.isNotEmpty) {
            widgets.add(_buildServicesList(quote.services));
            widgets.add(pw.SizedBox(height: 20));
          }
          
          // Adiciona custos extras
          if (quote.extraCosts.isNotEmpty) {
            widgets.add(_buildExtraCosts(quote.extraCosts));
            widgets.add(pw.SizedBox(height: 20));
          }
          
          // Adiciona valor total, termos e rodapé
          widgets.add(_buildTotalValue(quote));
          widgets.add(pw.SizedBox(height: 30));
          widgets.add(_buildTermsAndConditions(quote));
          widgets.add(pw.SizedBox(height: 30));
          widgets.add(_buildFooter(user, signatureWidget));
          
          return widgets;
        },
      ),
    );

    return pdf.save();
  }

  static Future<pw.Widget> _buildHeader(UserModel user) async {
    pw.Widget? logoWidget;
    
    // Sempre carrega a logo da aplicação
    try {
      final Uint8List appLogoBytes = await (await rootBundle.load('assets/images/logo.png')).buffer.asUint8List();
      final appLogoImage = pw.MemoryImage(appLogoBytes);
      logoWidget = pw.Container(
        height: 60,
        width: 100,
        alignment: pw.Alignment.centerLeft,
        decoration: pw.BoxDecoration(
          image: pw.DecorationImage(
            image: appLogoImage,
            fit: pw.BoxFit.contain,
          ),
        ),
      );
    } catch (e) {
      print('Erro ao carregar logo do app: $e');
      
      // Se falhar, tenta carregar a logo da empresa se estiver definida
      if (user.logoUrl.isNotEmpty) {
        try {
          final logoBytes = await getImageFromUrl(user.logoUrl);
          if (logoBytes != null) {
            final logoImage = pw.MemoryImage(logoBytes);
            logoWidget = pw.Container(
              height: 60,
              width: 120,
              decoration: pw.BoxDecoration(
                image: pw.DecorationImage(
                  image: logoImage,
                  fit: pw.BoxFit.contain,
                ),
              ),
            );
          }
        } catch (e) {
          print('Erro ao carregar logo: $e');
          logoWidget = null;
        }
      }
    }
    
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Row(
                children: [
                  if (logoWidget != null) ...[  
                    logoWidget,
                    pw.SizedBox(width: 12),
                  ],
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        user.companyName.isNotEmpty ? user.companyName : user.name,
                        style: pw.TextStyle(
                          fontSize: 24,
                          fontWeight: pw.FontWeight.bold,
                          color: PdfColors.blue,
                        ),
                      ),
                      pw.SizedBox(height: 8),
                      if (user.address.isNotEmpty)
                        pw.Text(user.address, style: const pw.TextStyle(fontSize: 12)),
                      if (user.phone.isNotEmpty)
                        pw.Text('Tel: ${user.phone}', style: const pw.TextStyle(fontSize: 12)),
                      pw.Text('Email: ${user.email}', style: const pw.TextStyle(fontSize: 12)),
                    ],
                  ),
                ],
              ),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: pw.BoxDecoration(
                  color: PdfColors.blue,
                  borderRadius: pw.BorderRadius.circular(4),
                ),
                child: pw.Text(
                  'ORÇAMENTO',
                  style: pw.TextStyle(
                    fontSize: 18,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.white,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  static Future<Uint8List?> getImageFromUrl(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        return response.bodyBytes;
      }
      return null;
    } catch (e) {
      print('Erro ao baixar imagem: $e');
      return null;
    }
  }

  static pw.Widget _buildCustomerInfo(QuoteModel quote) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey50,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'DADOS DO CLIENTE',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blue,
            ),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Cliente: ${quote.customerName}', style: const pw.TextStyle(fontSize: 12)),
                    pw.SizedBox(height: 4),
                    pw.Text('Endereço: ${quote.customerAddress}', style: const pw.TextStyle(fontSize: 12)),
                  ],
                ),
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('Data: ${_formatDate(quote.createdAt)}', style: const pw.TextStyle(fontSize: 12)),
                  pw.SizedBox(height: 4),
                  pw.Text('Validade: ${quote.validity} dias', style: const pw.TextStyle(fontSize: 12)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildProjectDetails(QuoteModel quote) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'DETALHES DO PROJETO',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blue,
            ),
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Text('Tipo de Serviço: ${quote.serviceType}', style: const pw.TextStyle(fontSize: 12)),
              ),
              pw.Expanded(
                child: pw.Text('Área: ${quote.area.toStringAsFixed(2)} m²', style: const pw.TextStyle(fontSize: 12)),
              ),
            ],
          ),
          pw.SizedBox(height: 8),
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Text('Tipo de Chapa: ${quote.sheetType}', style: const pw.TextStyle(fontSize: 12)),
              ),
              if (quote.footHeight > 0)
                pw.Expanded(
                  child: pw.Text('Pé-direito: ${quote.footHeight.toStringAsFixed(2)} m', style: const pw.TextStyle(fontSize: 12)),
                ),
            ],
          ),
          if (quote.includeInsulation)
            pw.Container(
              margin: const pw.EdgeInsets.only(top: 8),
              child: pw.Text('✓ Inclui isolamento térmico/acústico', style: const pw.TextStyle(fontSize: 12)),
            ),
        ],
      ),
    );
  }

  static pw.Widget _buildMaterialsList(List<MaterialItem> materials) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'LISTA DE MATERIAIS',
          style: pw.TextStyle(
            fontSize: 16,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.blue,
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey100),
              children: [
                _buildTableHeader('Material'),
                _buildTableHeader('Quantidade'),
                _buildTableHeader('Unidade'),
              ],
            ),
            ...materials.map((material) => pw.TableRow(
              children: [
                _buildTableCell(material.name),
                _buildTableCell(material.quantity.toStringAsFixed(2)),
                _buildTableCell(material.unit),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildServicesList(List<ServiceItem> services) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'SERVIÇOS',
          style: pw.TextStyle(
            fontSize: 16,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.blue,
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey100),
              children: [
                _buildTableHeader('Descrição'),
                _buildTableHeader('Área (m²)'),
                _buildTableHeader('Valor/m²'),
                _buildTableHeader('Total'),
              ],
            ),
            ...services.map((service) => pw.TableRow(
              children: [
                _buildTableCell(service.description),
                _buildTableCell(service.area.toStringAsFixed(2)),
                _buildTableCell('R\$ ${service.pricePerM2.toStringAsFixed(2)}'),
                _buildTableCell('R\$ ${service.total.toStringAsFixed(2)}'),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildExtraCosts(List<ExtraCost> extraCosts) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'CUSTOS EXTRAS',
          style: pw.TextStyle(
            fontSize: 16,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.blue,
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey100),
              children: [
                _buildTableHeader('Descrição'),
                _buildTableHeader('Valor'),
              ],
            ),
            ...extraCosts.map((cost) => pw.TableRow(
              children: [
                _buildTableCell(cost.description),
                _buildTableCell('R\$ ${cost.amount.toStringAsFixed(2)}'),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildTotalValue(QuoteModel quote) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: PdfColors.blue50,
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: PdfColors.blue),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'VALOR TOTAL DO ORÇAMENTO',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blue,
            ),
          ),
          pw.Text(
            'R\$ ${quote.totalValue.toStringAsFixed(2)}',
            style: pw.TextStyle(
              fontSize: 20,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blue,
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildTermsAndConditions(QuoteModel quote) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'CONDIÇÕES GERAIS',
          style: pw.TextStyle(
            fontSize: 14,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.blue,
          ),
        ),
        pw.SizedBox(height: 8),
        pw.Text(
          '• Validade da proposta: ${quote.validity} dias\n'
          '• Materiais inclusos conforme especificação\n'
          '• Mão de obra especializada\n'
          '• Garantia de 1 ano para serviços executados\n'
          '• Não inclui pintura final\n'
          '• Preços sujeitos à alteração sem aviso prévio',
          style: const pw.TextStyle(fontSize: 11),
        ),
        if (quote.customMessage.isNotEmpty) ...[
          pw.SizedBox(height: 12),
          pw.Text(
            'OBSERVAÇÕES',
            style: pw.TextStyle(
              fontSize: 14,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blue,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.Text(quote.customMessage, style: const pw.TextStyle(fontSize: 11)),
        ],
      ],
    );
  }

  static pw.Widget _buildFooter(UserModel user, pw.Widget? signatureWidget) {
    return pw.Column(
      children: [
        pw.Divider(color: PdfColors.grey300),
        pw.SizedBox(height: 16),
        pw.Text(
          user.defaultSlogan,
          style: pw.TextStyle(
            fontSize: 12,
            fontStyle: pw.FontStyle.italic,
            color: PdfColors.grey600,
          ),
          textAlign: pw.TextAlign.center,
        ),
        pw.SizedBox(height: 16),
        if (signatureWidget != null) ...[  
          pw.Center(child: signatureWidget),
          pw.SizedBox(height: 4),
        ],
        pw.Text(
          'Atenciosamente,\n${user.name}',
          style: const pw.TextStyle(fontSize: 12),
          textAlign: pw.TextAlign.center,
        ),
      ],
    );
  }

  static pw.Widget _buildTableHeader(String text) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontSize: 12,
          fontWeight: pw.FontWeight.bold,
        ),
        textAlign: pw.TextAlign.center,
      ),
    );
  }

  static pw.Widget _buildTableCell(String text) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: const pw.TextStyle(fontSize: 11),
        textAlign: pw.TextAlign.center,
      ),
    );
  }

  static String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  static Future<void> sharePdf({
    required Uint8List pdfBytes,
    required String fileName,
    String? text,
    String? subject,
  }) async {
    try {
      // Salva o PDF em um local acessível
      final filePath = await savePdf(pdfBytes: pdfBytes, fileName: fileName);
      final file = File(filePath);

      if (!await file.exists()) {
        throw Exception('Arquivo não foi criado corretamente');
      }

      // Compartilha o arquivo
      try {
        // Tenta outro método de compartilhamento
        await Share.share(
          'Orçamento de Drywall: $fileName',
          subject: subject ?? 'Orçamento ${fileName.replaceAll('_', ' ')}',
        );
      } catch (shareError) {
        print('Erro ao compartilhar com shareXFiles: $shareError');
        // Fallback para método alternativo
        // Tenta outro método de compartilhamento
        await Share.share(
          'Orçamento de Drywall: $fileName',
          subject: subject ?? 'Orçamento ${fileName.replaceAll('_', ' ')}',
        );
      }
    } catch (e) {
      print('Erro ao compartilhar PDF: $e');
      throw Exception('Não foi possível compartilhar o arquivo: $e');
    }
  }
  
  static Future<String> savePdf({
    required Uint8List pdfBytes,
    required String fileName,
  }) async {
    try {
      // Para Android e iOS, tentamos salvar em locais apropriados
      Directory directory;

      // Primeira opção: diretório de downloads (Android)
      if (Platform.isAndroid) {
        try {
          // Em Android 10+ (API 29+), usamos getExternalStorageDirectory
          directory = (await getExternalStorageDirectory())!;
          // Tenta criar uma pasta "Downloads" se não existir
          Directory downloadsDir = Directory('${directory.path}/Download');
          if (!await downloadsDir.exists()) {
            downloadsDir = await downloadsDir.create(recursive: true);
          }
          directory = downloadsDir;
        } catch (e) {
          print('Erro ao acessar diretório de downloads: $e');
          // Fallback para o diretório de documentos
          directory = await getApplicationDocumentsDirectory();
        }
      } 
      // Para iOS e outros, usa o diretório de documentos
      else {
        directory = await getApplicationDocumentsDirectory();
      }

      final filePath = '${directory.path}/$fileName.pdf';
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);
      print('PDF salvo com sucesso em: $filePath');
      return filePath;
    } catch (e) {
      print('Erro ao salvar PDF no diretório principal: $e');
      
      // Fallback: se os métodos acima falharem, tenta o diretório temporário
      try {
        final tempDir = await getTemporaryDirectory();
        final filePath = '${tempDir.path}/$fileName.pdf';
        final file = File(filePath);
        await file.writeAsBytes(pdfBytes);
        print('PDF salvo no diretório temporário: $filePath');
        return filePath;
      } catch (tempError) {
        print('Erro ao salvar no diretório temporário: $tempError');
        
        // Último recurso: tentar salvar em um local acessível sem path_provider
        try {
          final filePath = '$fileName.pdf';
          final file = File(filePath);
          await file.writeAsBytes(pdfBytes);
          print('PDF salvo com método alternativo: $filePath');
          return filePath;
        } catch (finalError) {
          throw Exception('Erro ao salvar PDF: $finalError (erro original: $e)');
        }
      }
    }
  }

  static Future<void> shareToWhatsApp({
    required Uint8List pdfBytes,
    required String fileName,
    String? phoneNumber,
    String? message,
  }) async {
    try {
      // Obtém o diretório temporário ou documentos acessível pelo app
      Directory directory;
      try {
        directory = await getTemporaryDirectory();
      } catch (e) {
        print('Erro ao obter diretório temporário: $e');
        directory = await getApplicationDocumentsDirectory();
      }

      // Cria o arquivo PDF no diretório acessível
      final filePath = '${directory.path}/$fileName.pdf';
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);
      print('PDF salvo com sucesso em: $filePath');
      
      // Verifica se o arquivo existe antes de compartilhar
      final fileExists = await file.exists();
      if (!fileExists) {
        throw Exception('Arquivo PDF não encontrado no caminho: $filePath');
      }
      
      // Compartilha o arquivo usando o share_plus
      try {
        await Share.shareXFiles(
          [XFile(file.path)],
          text: message ?? 'Orçamento de Drywall',
          subject: 'Orçamento para ${fileName.replaceAll('_', ' ')}',
        );
      } catch (e) {
        print('Erro no compartilhamento genérico: $e');
        // Tenta um fallback
        // Tenta outro método de compartilhamento
        await Share.share(
          message ?? 'Orçamento de Drywall',
          subject: 'Orçamento para ${fileName.replaceAll('_', ' ')}',
        );
      }
    } catch (e) {
      print('Erro ao compartilhar via WhatsApp: $e');
      throw Exception('Não foi possível compartilhar o arquivo: $e');
    }
  }

  static Future<void> printPdf(Uint8List pdfBytes) async {
    await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdfBytes);
  }
  
  static Future<String> downloadPdf({
    required Uint8List pdfBytes,
    required String fileName,
  }) async {
    try {
      // Tenta obter o diretório de Downloads em Android
      Directory? directory;
      
      if (Platform.isAndroid) {
        try {
          // Em Android, tenta usar o diretório de downloads público
          directory = Directory('/storage/emulated/0/Download');
          if (!await directory.exists()) {
            directory = await getExternalStorageDirectory();
          }
        } catch (e) {
          print('Erro ao acessar diretório de downloads público: $e');
          directory = await getExternalStorageDirectory();
        }
      } else {
        // Em iOS, usa o diretório de documentos
        directory = await getApplicationDocumentsDirectory();
      }

      if (directory == null) {
        throw Exception('Não foi possível acessar o diretório de downloads');
      }

      final filePath = '${directory.path}/$fileName.pdf';
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);
      
      print('PDF baixado com sucesso em: $filePath');
      return filePath;
    } catch (e) {
      print('Erro ao baixar PDF: $e');
      
      // Fallback - salva no diretório de documentos
      final directory = await getApplicationDocumentsDirectory();
      final filePath = '${directory.path}/$fileName.pdf';
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);
      
      return filePath;
    }
  }
  
  static Future<Uint8List> generateCalculatorPdf({
    required UserModel user,
    required String serviceType,
    required double area,
    required String sheetType,
    required bool includeInsulation,
    required List<MaterialItem> materials,
  }) async {
    final pdf = pw.Document();
    
    // Carrega a logo do usuário se disponível
    final headerWidget = await _buildHeader(user);
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (pw.Context context) {
          return [
            headerWidget,
            pw.SizedBox(height: 20),
            
            // Detalhes do cálculo
            pw.Container(
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey300),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'DETALHES DO CÁLCULO',
                    style: pw.TextStyle(
                      fontSize: 16,
                      fontWeight: pw.FontWeight.bold,
                      color: PdfColors.blue,
                    ),
                  ),
                  pw.SizedBox(height: 12),
                  pw.Row(
                    children: [
                      pw.Expanded(
                        child: pw.Text('Tipo de Serviço: $serviceType', style: const pw.TextStyle(fontSize: 12)),
                      ),
                      pw.Expanded(
                        child: pw.Text('Área: ${area.toStringAsFixed(2)} m²', style: const pw.TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  pw.SizedBox(height: 8),
                  pw.Row(
                    children: [
                      pw.Expanded(
                        child: pw.Text('Tipo de Chapa: $sheetType', style: const pw.TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  if (includeInsulation)
                    pw.Container(
                      margin: const pw.EdgeInsets.only(top: 8),
                      child: pw.Text('✓ Inclui isolamento térmico/acústico', style: const pw.TextStyle(fontSize: 12)),
                    ),
                ],
              ),
            ),
            
            pw.SizedBox(height: 20),
            
            // Lista de materiais
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'LISTA DE MATERIAIS NECESSÁRIOS',
                  style: pw.TextStyle(
                    fontSize: 16,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.blue,
                  ),
                ),
                pw.SizedBox(height: 12),
                pw.Table(
                  border: pw.TableBorder.all(color: PdfColors.grey300),
                  children: [
                    pw.TableRow(
                      decoration: const pw.BoxDecoration(color: PdfColors.grey100),
                      children: [
                        _buildTableHeader('Material'),
                        _buildTableHeader('Quantidade'),
                        _buildTableHeader('Unidade'),
                      ],
                    ),
                    ...materials.map((material) => pw.TableRow(
                      children: [
                        _buildTableCell(material.name),
                        _buildTableCell(material.quantity.toStringAsFixed(2)),
                        _buildTableCell(material.unit),
                      ],
                    )),
                  ],
                ),
              ],
            ),
            
            pw.SizedBox(height: 30),
            
            // Rodapé
            pw.Column(
              children: [
                pw.Divider(color: PdfColors.grey300),
                pw.SizedBox(height: 16),
                pw.Text(
                  user.defaultSlogan,
                  style: pw.TextStyle(
                    fontSize: 12,
                    fontStyle: pw.FontStyle.italic,
                    color: PdfColors.grey600,
                  ),
                  textAlign: pw.TextAlign.center,
                ),
                pw.SizedBox(height: 8),
                pw.Text(
                  'Documento gerado em ${_formatDate(DateTime.now())}',
                  style: const pw.TextStyle(fontSize: 10),
                  textAlign: pw.TextAlign.center,
                ),
              ],
            ),
          ];
        },
      ),
    );
    
    return pdf.save();
  }
}