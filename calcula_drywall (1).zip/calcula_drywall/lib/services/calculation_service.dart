import '../data_schema.dart';

class CalculationService {
  // Define service types and subtypes
  static const Map<String, List<String>> serviceSubtypes = {
    'Parede': ['Parede simples', 'Parede com revestimento colado', 'Parede com revestimento estruturado'],
    'Teto': ['Forro FGA (aramado)', 'Forro FGE (estruturado)'],
  };
  
  static const Map<String, List<MaterialFormula>> _materialFormulas = {
    'Parede simples': [
      MaterialFormula(name: 'Chapa de Drywall', unit: 'm²', factor: 6.3),
      MaterialFormula(name: 'Montante Metálico', unit: 'm', factor: 3.2),
      MaterialFormula(name: 'Guia Metálica', unit: 'm', factor: 0.8),
      MaterialFormula(name: 'Parafuso Drywall', unit: 'unidades', factor: 25),
      MaterialFormula(name: 'Fita para Juntas', unit: 'm', factor: 4.2),
      MaterialFormula(name: 'Massa para Juntas', unit: 'kg', factor: 1.8),
    ],
    'Parede com revestimento colado': [
      MaterialFormula(name: 'Chapa de Drywall', unit: 'm²', factor: 1.05),
      MaterialFormula(name: 'Cola para Drywall', unit: 'kg', factor: 1.0),
      MaterialFormula(name: 'Parafuso Drywall', unit: 'unidades', factor: 8),
      MaterialFormula(name: 'Fita para Juntas', unit: 'm', factor: 3.2),
      MaterialFormula(name: 'Massa para Juntas', unit: 'kg', factor: 1.2),
    ],
    'Parede com revestimento estruturado': [
      MaterialFormula(name: 'Chapa de Drywall', unit: 'm²', factor: 1.05),
      MaterialFormula(name: 'Montante Metálico', unit: 'm', factor: 3.2),
      MaterialFormula(name: 'Guia Metálica', unit: 'm', factor: 0.6),
      MaterialFormula(name: 'Parafuso Drywall', unit: 'unidades', factor: 15),
      MaterialFormula(name: 'Fita para Juntas', unit: 'm', factor: 3.2),
      MaterialFormula(name: 'Massa para Juntas', unit: 'kg', factor: 1.2),
    ],
    'Forro FGA (aramado)': [
      MaterialFormula(name: 'Chapa de Drywall', unit: 'm²', factor: 1.05),
      MaterialFormula(name: 'Perfil T24', unit: 'm', factor: 3.2),
      MaterialFormula(name: 'Perfil L24', unit: 'm', factor: 1.2),
      MaterialFormula(name: 'Arame Galvanizado', unit: 'm', factor: 4.0),
      MaterialFormula(name: 'Parafuso Drywall', unit: 'unidades', factor: 20),
      MaterialFormula(name: 'Fita para Juntas', unit: 'm', factor: 3.8),
      MaterialFormula(name: 'Massa para Juntas', unit: 'kg', factor: 1.5),
    ],
    'Forro FGE (estruturado)': [
      MaterialFormula(name: 'Chapa de Drywall', unit: 'm²', factor: 1.05),
      MaterialFormula(name: 'Perfil F530', unit: 'm', factor: 1.0),
      MaterialFormula(name: 'Perfil M520', unit: 'm', factor: 3.3),
      MaterialFormula(name: 'Pendural', unit: 'unidades', factor: 0.7),
      MaterialFormula(name: 'Conector', unit: 'unidades', factor: 2.8),
      MaterialFormula(name: 'Parafuso Drywall', unit: 'unidades', factor: 20),
      MaterialFormula(name: 'Fita para Juntas', unit: 'm', factor: 3.8),
      MaterialFormula(name: 'Massa para Juntas', unit: 'kg', factor: 1.5),
    ],
  };

  static const Map<String, String> _serviceDescriptions = {
    'Parede simples': 'Execução de parede simples em drywall',
    'Parede com revestimento colado': 'Execução de parede com revestimento colado em drywall',
    'Parede com revestimento estruturado': 'Execução de parede com revestimento estruturado em drywall',
    'Forro FGA (aramado)': 'Execução de forro aramado em drywall',
    'Forro FGE (estruturado)': 'Execução de forro estruturado em drywall',
  };

  static List<MaterialItem> calculateMaterials({
    required String serviceType,
    required double area,
    bool includeInsulation = false,
  }) {
    final formulas = _materialFormulas[serviceType] ?? [];
    final materials = <MaterialItem>[];

    for (final formula in formulas) {
      final quantity = area * formula.factor;
      materials.add(MaterialItem(
        name: formula.name,
        unit: formula.unit,
        quantity: double.parse(quantity.toStringAsFixed(2)),
        factor: formula.factor,
      ));
    }

    // Add insulation if requested
    if (includeInsulation) {
      materials.add(MaterialItem(
        name: 'Lã de Vidro/Lã de Rocha',
        unit: 'm²',
        quantity: double.parse(area.toStringAsFixed(2)),
        factor: 1.0,
      ));
    }

    return materials;
  }

  static List<ServiceItem> calculateServices({
    required String serviceType,
    required double area,
    required double pricePerM2,
  }) {
    final description = _serviceDescriptions[serviceType] ?? serviceType;
    final total = area * pricePerM2;

    return [
      ServiceItem(
        description: description,
        area: area,
        pricePerM2: pricePerM2,
        total: double.parse(total.toStringAsFixed(2)),
      ),
    ];
  }

  static List<String> getMainServiceTypes() {
    return serviceSubtypes.keys.toList();
  }
  
  static List<String> getServiceSubtypes(String mainType) {
    return serviceSubtypes[mainType] ?? [];
  }
  
  static List<String> getAvailableServiceTypes() {
    return _materialFormulas.keys.toList();
  }

  static List<String> getAvailableSheetTypes() {
    return ['ST (Standard)', 'RU (Resistente à Umidade)', 'RF (Resistente ao Fogo)'];
  }

  static String formatQuantity(double quantity, String unit) {
    if (quantity == quantity.toInt()) {
      return '${quantity.toInt()} $unit';
    }
    return '${quantity.toStringAsFixed(2)} $unit';
  }
}

class MaterialFormula {
  final String name;
  final String unit;
  final double factor;

  const MaterialFormula({
    required this.name,
    required this.unit,
    required this.factor,
  });
}