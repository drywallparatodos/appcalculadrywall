O aplicativo possui as seguintes estruturas e funcionalidades:

1. **Serviços:**
   - **PdfService**: Serviço para geração, compartilhamento, download e impressão de PDFs
     - Funções de geração de PDF para orçamentos e cálculos
     - Função `sharePdf`: compartilhamento genérico de PDFs
     - Função `shareToWhatsApp`: compartilhamento específico para WhatsApp
     - Função `savePdf`: salvamento de PDFs no armazenamento do dispositivo
     - Função `downloadPdf`: download de PDFs
     - Função `printPdf`: impressão de PDFs
   - **AuthService**: Gerenciamento de autenticação
   - **CalculationService**: Serviço para cálculos relacionados a orçamentos

2. **Telas:**
   - **AuthScreen**: Tela de autenticação
   - **HomeScreen**: Tela principal
   - **CalculatorScreen**: Tela de calculadora
   - **BudgetScreen**: Tela de orçamento
   - **ProfileScreen**: Tela de perfil
   - **SplashScreen**: Tela de inicialização

3. **Utilitários:**
   - **ImageUtil**: Serviço para manipulação de imagens
   - **DataSchema**: Definição dos modelos de dados
   - **Theme**: Configurações de tema do aplicativo

4. **Permissões configuradas:**
   - Android: Internet, leitura/escrita de armazenamento externo, gerenciamento de armazenamento
   - iOS: Acesso à biblioteca de fotos, documentos, suporte a compartilhamento

5. **Principais dependências:**
   - pdf: Geração de PDFs
   - printing: Impressão de PDFs
   - path_provider: Acesso a diretórios do sistema
   - share_plus: Compartilhamento de arquivos
   - url_launcher: Abertura de URLs
   - flutter/foundation, flutter/services: Serviços base do Flutter
   - http: Requisições HTTP