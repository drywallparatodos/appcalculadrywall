package com.mycompany.OrçamentoseCompartilhamento

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
